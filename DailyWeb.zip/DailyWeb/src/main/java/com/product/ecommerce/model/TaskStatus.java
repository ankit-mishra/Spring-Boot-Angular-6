package com.product.ecommerce.model;

public enum TaskStatus {
    DONE
}
