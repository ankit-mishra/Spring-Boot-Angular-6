import {EmployeeTask} from "./employee-task.model";

export class EmployeeTasks {
    employeeTasks: EmployeeTask[] = [];
}
